const serverless = require('serverless-http');
const express = require('express');
const errorController = require('./controllers/error');
const jobPartRoutes = require('./routes/companyZ');
var cors = require('cors')

const app = express();
app.use(express.json());
app.use(cors());
app.set('view engine', 'ejs');
app.set('views', 'views');


//routing the requests to the jobPart router
app.use(jobPartRoutes);

app.use(errorController.get404);

module.exports.handler = serverless(app);
